<template>
  <div id="app">
    <PetListing />
  </div>
</template>

<script lang="ts">
import { defineComponent } from '@vue/composition-api'
import fetch from 'cross-fetch'
import { useClient } from 'villus'

import PetListing from '~/components/PetListing.vue'

export default defineComponent({
  'components': {
    PetListing,
  },
  setup () {
    useClient({
      'url': 'https://pet-library.moonhighway.com/',
      fetch,
    })
  },
})
</script>

<style scoped>
/* stylelint-disable */
img {
  width: 200px;
}
h1 {
  font-family: Arial, Helvetica, sans-serif;
}

#app {
  width: 100vw;
  height: 100vh;
}
</style>

<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
</style>
